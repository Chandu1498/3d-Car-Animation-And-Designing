#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <GL/glut.h>
#include <math.h>
#include<string>

#include "imageloader.h"


float car_x[1000000];
float car_y[1000000];
int car_no = 0;
int car_start = 0;
int car_color[1000000];


float car_x2[1000000];
float car_y2[1000000];
int car_no2 = 0;
int car_start2 = 0;
int car_color2[1000000];


int iSecret, iGuess;

float time_elapsed = 0;
int time_limit = 110;
float x = 0, y = 0;
bool game_over = false;
//value for Bitmap Font
float x_bf = 0.12f*0.0033, y_bf = 0.10f*0.0025;

int score = 0;

using namespace std;
int path = 1;

GLuint _textureId;
GLuint _textureId1;


// for text drawing

void drawBitmapText(char *string, float x, float y, float z)
{
	char *c;
	glRasterPos3f(x, y, z);

	for (c = string; *c != '\0'; c++)
	{
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, *c);
	}
}

void drawStrokeText(char*string, float x, float y, int z)
{
	char *c;
	glPushMatrix();
	glTranslatef(x, y + (8 * 0.0025), z);
	glScalef(x_bf, y_bf, z);

	for (c = string; *c != '\0'; c++)
	{
		glutStrokeCharacter(GLUT_STROKE_ROMAN, *c);
	}
	glPopMatrix();
}


//num to string 

string num_to_str(int num) {
	string s = "";
	do {
		int mod = num % 10;
		if (mod == 1) {
			s = '1' + s;
		}
		else if (mod == 2) {
			s = '2' + s;
		}
		else if (mod == 3) {
			s = '3' + s;
		}
		else if (mod == 4) {
			s = '4' + s;
		}
		else if (mod == 5) {
			s = '5' + s;
		}
		else if (mod == 6) {
			s = '6' + s;
		}
		else if (mod == 7) {
			s = '7' + s;
		}
		else if (mod == 8) {
			s = '8' + s;
		}
		else if (mod == 9) {
			s = '9' + s;
		}
		else if (mod == 0) {
			s = '0' + s;
		}
		num = num / 10;
	} while (num != 0);
	return s;
}

bool isUpKeyPressed, isDownKeyPressed;
void handleSpecialKeyPress(int key, int u, int d){
	switch (key){
	case GLUT_KEY_UP:
			isUpKeyPressed = true;
			if (!isDownKeyPressed && !game_over){
				if (y <0.1)
				{
					y = y + (25 * 0.0025);
					glutPostRedisplay();
				}
			}
			break;
	case GLUT_KEY_DOWN:
		isDownKeyPressed = true;
		if (!isUpKeyPressed && !game_over){
			if (y > -1.5)
			{
				y = y - (25 * 0.0025);
				glutPostRedisplay();
			}
		}
		break;
	}

}


void handleSpecialKeyReleased(int key, int u, int d){
	switch (key){
	case GLUT_KEY_UP:
		isUpKeyPressed = false;
			break;
		case GLUT_KEY_DOWN:
			isDownKeyPressed = false;
	break;
	}
}




void keyboard(unsigned char key, int xx, int yy)
{
	if (key == 'y' && !game_over)
	{
		if (y <0.1)
		{
			y = y + (15 * 0.0025);
			glutPostRedisplay();
		}
	}
	else if (key == 'b' && !game_over)
	{
		if (y > -1.5)
		{
			y = y - (15 * 0.0025);
			glutPostRedisplay();
		}
	}
	else if (key == 'r' && game_over)
	{
		if (game_over == true) {
			x = 0;
			y = 0;
			car_no = 0;
			car_no2 = 0;
			score = 0;
			path = 1;
			game_over = false;
		}
	}
}



void doCirclefill(int b_i, float x, float y, float radius) {
	glEnable(GL_BLEND);
	glColor4f(0.0, 0.0, 1.0, 0.0);
	float y1 = y;
	float x1 = x;
	glBegin(GL_TRIANGLES);
	for (int i = 0; i <= 360; i++)
	{
		float angle = (float)(((float)i) / 57.29577957795135);
		float x2 = x + (radius*(float)sin((float)angle));
		float y2 = y + (radius*(float)cos((float)angle));
		glVertex2f(x, y);
		glVertex2f(x1, y1);
		glVertex2f(x2, y2);
		y1 = y2;
		x1 = x2;
	}
	glEnd();
	glDisable(GL_BLEND);
}


void drawScene() {
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	glPushMatrix();

	glTranslatef(0.0, 0.0, -5.0f);

	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, _textureId);


	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glColor3f(1.0f, 1.0f, 1.0f);
	glBegin(GL_QUADS);

	glNormal3f(0.0f, 0.0f, 1.0f);

	glTexCoord2f(0.0, 0.0);
	glVertex3f(-1.0, -1.0, 0.0);

	glTexCoord2f(0.0, 1.0);
	glVertex3f(-1.0, 1.0, 0.0);

	glTexCoord2f(1.0, 1.0);
	glVertex3f(1.0, 1.0, 0.0);

	glTexCoord2f(1.0, 0.0);
	glVertex3f(1.0, -1.0, 0.0);

	glEnd();

	glPopMatrix();

	glDisable(GL_TEXTURE_2D);

	glPushMatrix();

	glTranslatef(-1.0, -1.0, -5.0f);





	///cus


	time_t seconds;

	seconds = time(NULL);

	/* initialize random seed: */
	srand(time(NULL));

	/* generate secret number between 1 and 10: */
	iSecret = rand() % 10 + 1;

	if (time_elapsed>time_limit && !game_over) {
		car_x[car_no] = -(85*0.0033);
		car_y[car_no] = 0;
		srand(time(NULL));
		car_color[car_no] = rand() % 3 + 1;
		car_no++;


		car_x2[car_no2] = (800*0.0033);
		car_y2[car_no2] = -(250*0.0025);
		srand(time(NULL));
		car_color2[car_no2] = rand() % 3 + 1;
		car_no2++;


		seconds = time(NULL);
		time_elapsed = 0;
		srand(time(NULL));
		//cargenarated time
		time_limit = rand() % 50 + 15;
	}

	//car1
	for (int i = car_start; i < car_no; i++) {
		glBegin(GL_POLYGON);
		if (car_color[i] == 1) glColor3f(1.0f, 0.0f, 0.0f);
		else if (car_color[i] == 2) glColor3f(0.0f, 1.0f, 0.0f);
		else if (car_color[i] == 3) glColor3f(1.0f, 1.0f, 0.0f);
		else glColor3f(0.0f, 0.5f, 0.5f);
		glVertex2f(car_x[i] + (20 * 0.0033), car_y[i] + (520 * 0.0025));
		glVertex2f(car_x[i] + (60 * 0.0033), car_y[i] + (520 * 0.0025));
		glVertex2f(car_x[i] + (60 * 0.0033), car_y[i] + (500 * 0.0025));
		glVertex2f(car_x[i] + (20 * 0.0033), car_y[i] + (500 * 0.0025));
		glEnd();
		//glFlush();
		glBegin(GL_POLYGON);
		glVertex2f(car_x[i], car_y[i] + (500 * 0.0025));
		glVertex2f(car_x[i] + (85 * 0.0033), car_y[i] + (500 * 0.0025));
		glVertex2f(car_x[i] + (85 * 0.0033), car_y[i] + (465 * 0.0025));
		glVertex2f(car_x[i], car_y[i] + (465 * 0.0025));
		glEnd();
		glColor3f(0.0f, 0.5f, 0.5f);
		doCirclefill(0, car_x[i] + (20 * 0.0033), car_y[i] + (470*0.0025), (10 * 0.0025));
		glColor3f(0.0f, 0.5f, 0.5f);
		doCirclefill(0, car_x[i] + (60 * 0.0033), car_y[i] + (470*0.0025), (10 * 0.0025));
		glEnd();

		glBegin(GL_POLYGON);
		if (car_color2[i] == 1) glColor3f(1.0f, 0.0f, 0.0f);
		else if (car_color2[i] == 2) glColor3f(0.0f, 1.0f, 0.0f);
		else if (car_color2[i] == 3) glColor3f(1.0f, 1.0f, 0.0f);
		else glColor3f(0.0f, 0.5f, 0.5f);
		glVertex2f(car_x2[i] + (20 * 0.0033), car_y2[i] + (520 * 0.0025));
		glVertex2f(car_x2[i] + (60 * 0.0033), car_y2[i] + (520 * 0.0025));
		glVertex2f(car_x2[i] + (60 * 0.0033), car_y2[i] + (500 * 0.0025));
		glVertex2f(car_x2[i] + (20 * 0.0033), car_y2[i] + (500 * 0.0025));
		glEnd();
		//glFlush();
		glBegin(GL_POLYGON);
		glVertex2f(car_x2[i], car_y2[i] + (500 * 0.0025));
		glVertex2f(car_x2[i] + (85 * 0.0033), car_y2[i] + (500 * 0.0025));
		glVertex2f(car_x2[i] + (85 * 0.0033), car_y2[i] + (465 * 0.0025));
		glVertex2f(car_x2[i], car_y2[i] + (465 * 0.0025));
		glEnd();
		glColor3f(0.0f, 0.5f, 0.5f);
		doCirclefill(0, car_x2[i] + (20 * 0.0033), car_y2[i] + (470 * 0.0025), (10 * 0.0025));
		glColor3f(0.0f, 0.5f, 0.5f);
		doCirclefill(0, car_x2[i] + (60 * 0.0033), car_y2[i] + (470 * 0.0025), (10 * 0.0025));




	}


	///cus end










	glColor3f(0.0f, 0.5f, 0.5f);

	//man
	//head
	doCirclefill(0, x + (310 * 0.0033), y + (690 * 0.0025), (7 * 0.0025));
	//body
	glBegin(GL_QUADS);
	glVertex2f(x + (295 * 0.0033), y + (680 * 0.0025));
	glVertex2f(x + (300 * 0.0033), y + (680 * 0.0025));
	glVertex2f(x + (300 * 0.0033), y + (660 * 0.0025));
	glVertex2f(x + (295 * 0.0033), y + (660 * 0.0025));
	glEnd();
	//righthand
	glBegin(GL_QUADS);
	glVertex2f(x + (305 * 0.0033), y + (680 * 0.0025));
	glVertex2f(x + (315 * 0.0033), y + (680 * 0.0025));
	glVertex2f(x + (315 * 0.0033), y + (640 * 0.0025));
	glVertex2f(x + (305 * 0.0033), y + (640 * 0.0025));
	glEnd();
	//lefthand
	glBegin(GL_QUADS);
	glVertex2f(x + (320 * 0.0033), y + (680 * 0.0025));
	glVertex2f(x + (325 * 0.0033), y + (680 * 0.0025));
	glVertex2f(x + (325 * 0.0033), y + (660 * 0.0025));
	glVertex2f(x + (320 * 0.0033), y + (660 * 0.0025));
	glEnd();

	glBegin(GL_QUADS);
	glVertex2f(x + (301 * 0.0033), y + (645 * 0.0025));
	glVertex2f(x + (305 * 0.0033), y + (645 * 0.0025));
	glVertex2f(x + (305 * 0.0033), y + (615 * 0.0025));
	glVertex2f(x + (301 * 0.0033), y + (615 * 0.0025));
	glEnd();

	glBegin(GL_QUADS);
	glVertex2f(x + (315 * 0.0033), y + (645 * 0.0025));
	glVertex2f(x + (320 * 0.0033), y + (645 * 0.0025));
	glVertex2f(x + (320 * 0.0033), y + (615 * 0.0025));
	glVertex2f(x + (315 * 0.0033), y + (615 * 0.0025));
	glEnd();

	x_bf = 0.12f*0.0033, y_bf = 0.10f*0.0025;
	glColor3f(0, 1, 0);
	string ttd = "";
	ttd = ttd + "Score: " + num_to_str(score);
	char *a;
	a = &ttd[0];
	drawStrokeText(a, 280 * 0.0033, 750 * 0.0025, 0);

	if (game_over == 1) {
		x_bf = 0.32f*0.0033; y_bf = 0.30f*0.0025;
		glColor3f(1, 0, 1);
		drawStrokeText("Game Over", 200 * 0.0033, 240 * 0.0025, 0);
	}

	glPopMatrix();





	for (int i = car_start; i < car_no && !game_over; i++) {


		if (car_x[i] + (20 * 0.0033) < x + (300 * 0.0033) && car_x[i] + (60 * 0.0033) > x + (300 * 0.0033)) {
			if (car_y[i] + (500 * 0.0025) < y + (687 * 0.0025) && car_y[i] + (500 * 0.0025) + (20 * 0.0025) > y + (687 * 0.0025)) {
				game_over = true;
				break;
			}
			else if (car_y[i] + (500 * 0.0025) < y + (615 * 0.0025) && car_y[i] + (500 * 0.0025) + (20 * 0.0025) > y + (615 * 0.0025)) {
				game_over = true;
				break;
			}
			else if (car_y[i] + (500 * 0.0025) < y + (640 * 0.0025) && car_y[i] + (500 * 0.0025) + (20 * 0.0025) > y + (640 * 0.0025)) {
				game_over = true;
				break;
			}
		}
		if (car_x[i] + (20 * 0.0033) < x + (320 * 0.0033) && car_x[i] + (60 * 0.0033) > x + (320 * 0.0033)) {
			if (car_y[i] + (500 * 0.0025) < y + (687 * 0.0025) && car_y[i] + (500 * 0.0025) + (20 * 0.0025) > y + (687 * 0.0025)) {
				game_over = true;
				break;
			}
			else if (car_y[i] + (500 * 0.0025) < y + (615 * 0.0025) && car_y[i] + (500 * 0.0025) + (20 * 0.0025) > y + (615 * 0.0025)) {
				game_over = true;
				break;
			}
			else if (car_y[i] + (500 * 0.0025) < y + (640 * 0.0025) && car_y[i] + (500 * 0.0025) + (20 * 0.0025) > y + (640 * 0.0025)) {
				game_over = true;
				break;
			}
		}




		if (car_x2[i] + (20 * 0.0033) < x + (300 * 0.0033) && car_x2[i] + (60 * 0.0033) > x + (300 * 0.0033)) {
			if (car_y2[i] + (500 * 0.0025) < y + (687 * 0.0025) && car_y2[i] + (500 * 0.0025) + (20 * 0.0025) > y + (687 * 0.0025)) {
				game_over = true;
				break;
			}
			else if (car_y2[i] + (500 * 0.0025) < y + (615 * 0.0025) && car_y2[i] + (500 * 0.0025) + (20 * 0.0025) > y + (615 * 0.0025)) {
				game_over = true;
				break;
			}
			else if (car_y2[i] + (500 * 0.0025) < y + (640 * 0.0025) && car_y2[i] + (500 * 0.0025) + (20 * 0.0025) > y + (640 * 0.0025)) {
				game_over = true;
				break;
			}
		}
		if (car_x2[i] + (20 * 0.0033) < x + (320 * 0.0033) && car_x2[i] + (60 * 0.0033) > x + (320 * 0.0033)) {
			if (car_y2[i] + (500 * 0.0025) < y + (687 * 0.0025) && car_y2[i] + (500 * 0.0025) + (20 * 0.0025) > y + (687 * 0.0025)) {
				game_over = true;
				break;
			}
			else if (car_y2[i] + (500 * 0.0025) < y + (615 * 0.0025) && car_y2[i] + (500 * 0.0025) + (20 * 0.0025) > y + (615 * 0.0025)) {
				game_over = true;
				break;
			}
			else if (car_y2[i] + (500 * 0.0025) < y + (640 * 0.0025) && car_y2[i] + (500 * 0.0025) + (20 * 0.0025) > y + (640 * 0.0025)) {
				game_over = true;
				break;
			}
		}



		if (car_x2[i] + (0 * 0.0033) < x + (300 * 0.0033) && car_x2[i] + (85 * 0.0033)> x + (300 * 0.0033)) {
			if (car_y2[i] + (455 * 0.0025) < y + (687 * 0.0025) && car_y2[i] + (500 * 0.0025) > y + (687 * 0.0025)) {
				game_over = true;
				break;
			}
			else if (car_y2[i] + (455 * 0.0025) < y + (615 * 0.0025) && car_y2[i] + (500 * 0.0025) > y + (615 * 0.0025)) {
				game_over = true;
				break;
			}
			else if (car_y2[i] + (455 * 0.0025) < y + (640 * 0.0025) && car_y2[i] + (500 * 0.0025) > y + (640 * 0.0025)) {
				game_over = true;
				break;
			}
		}
		if (car_x2[i] + (0 * 0.0033) < x + (320 * 0.0033) && car_x2[i] + (85 * 0.0033) > x + (320 * 0.0033)) {
			if (car_y2[i] + (455 * 0.0025) < y + (687 * 0.0025) && car_y2[i] + (500 * 0.0025) > y + (687 * 0.0025)) {
				game_over = true;
				break;
			}
			else if (car_y2[i] + (455 * 0.0025) < y + (615 * 0.0025) && car_y2[i] + (500 * 0.0025) > y + (615 * 0.0025)) {
				game_over = true;
				break;
			}
			else if (car_y2[i] + (455 * 0.0025) < y + (640 * 0.0025) && car_y2[i] + (500 * 0.0025) > y + (640 * 0.0025)) {
				game_over = true;
				break;
			}
		}



		if (car_x[i] + (0 * 0.0033) < x + (300 * 0.0033) && car_x[i] + (85 * 0.0033)> x + (300 * 0.0033)) {
			if (car_y[i] + (455 * 0.0025) < y + (687 * 0.0025) && car_y[i] + (500 * 0.0025) > y + (687 * 0.0025)) {
				game_over = true;
				break;
			}
			else if (car_y[i] + (455 * 0.0025) < y + (615 * 0.0025) && car_y[i] + (500 * 0.0025) > y + (615 * 0.0025)) {
				game_over = true;
				break;
			}
			else if (car_y[i] + (455 * 0.0025) < y + (640 * 0.0025) && car_y[i] + (500 * 0.0025) > y + (640 * 0.0025)) {
				game_over = true;
				break;
			}
		}
		if (car_x[i] + (0 * 0.0033) < x + (320 * 0.0033) && car_x[i] + (85 * 0.0033) > x + (320 * 0.0033)) {
			if (car_y[i] + (455 * 0.0025) < y + (680 * 0.0025) && car_y[i] + (500 * 0.0025) > y + (680 * 0.0025)) {
				game_over = true;
				break;
			}
			else if (car_y[i] + (455 * 0.0025) < y + (615 * 0.0025) && car_y[i] + (500 * 0.0025) > y + (615 * 0.0025)) {
				game_over = true;
				break;
			}
			else if (car_y[i] + (455 * 0.0025) < y + (640 * 0.0025) && car_y[i] + (500 * 0.0025) > y + (640 * 0.0025)) {
				game_over = true;
				break;
			}
		}




		if (car_x[i]>(800 * 0.0033)) {
			car_start = i;
		}
		else {
			//carspeed
			car_x[i] = car_x[i] + (0.4* 0.0033);
		}
		if (car_x2[i]<-(85 * 0.0033)) {
			car_start2 = i;
		}
		else {
			car_x2[i] = car_x2[i] - (0.4* 0.0033);
		}
	}
	//score
	if (path == 1) {
		if (y + (690 * 0.0025) < 0.5) {
			score++;
			path = 0;
		}
	}
	else if (path == 0) {
		if (y+(690 * 0.0025)>1.8) {
			score++;
			path = 1;
		}
	}


	glutSwapBuffers();

	glutPostRedisplay();
	time_elapsed = time_elapsed + 0.05;
}

GLuint loadTexture(Image* image) {
	GLuint textureId;
	glGenTextures(1, &textureId); //Make room for our texture
	glBindTexture(GL_TEXTURE_2D, textureId); //Tell OpenGL which texture to edit
	//Map the image to the texture
	glTexImage2D(GL_TEXTURE_2D,                //Always GL_TEXTURE_2D
		0,                            //0 for now
		GL_RGB,                       //Format OpenGL uses for image
		image->width, image->height,  //Width and height
		0,                            //The border of the image
		GL_RGB, //GL_RGB, because pixels are stored in RGB format
		GL_UNSIGNED_BYTE, //GL_UNSIGNED_BYTE, because pixels are stored
		//as unsigned numbers
		image->pixels);               //The actual pixel data
	return textureId; //Returns the id of the texture
}

void initialize() {

	glClearColor(1.0, 1.0, 1.0, 1.0);
	glMatrixMode(GL_PROJECTION);
	gluPerspective(23.0, 1.00, 1.0, 200.0);
	//gluPerspective(23.0f, (GLfloat)1024 / (GLfloat)768, 1.0f, 100.0f);
	//Insert image path where it locates


	Image* image = loadBMP("C:\\Users\\User\\Desktop\\Project_test\\pattern-road-texture-20764759.bmp");

	_textureId = loadTexture(image);

	delete image;
	
}



int main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(800, 600);

	glutCreateWindow("Crossing");
	initialize();
	glutDisplayFunc(drawScene);
	glutSpecialFunc(handleSpecialKeyPress);
	glutSpecialUpFunc(handleSpecialKeyReleased);
	glutKeyboardFunc(keyboard);
	glutMainLoop();
	return 0;
}









